from django.apps import AppConfig


class AdmincontractsConfig(AppConfig):
    name = 'admincontracts'
