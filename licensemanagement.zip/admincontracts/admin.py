from django.contrib import admin
from .models import userdetail,ContractDetails
# Register your models here.

admin.site.register(userdetail)
admin.site.register(ContractDetails)
